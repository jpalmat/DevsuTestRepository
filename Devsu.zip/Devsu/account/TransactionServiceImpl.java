package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.exceptions.NoBalanceException;
import com.devsu.hackerearth.backend.account.exceptions.NoTransactionException;
import com.devsu.hackerearth.backend.account.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.model.Client;
import com.devsu.hackerearth.backend.account.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountService accountService;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountService accountService) {
        this.transactionRepository = transactionRepository;
        this.accountService = accountService;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll().stream()
        .map(TransactionMapper :: toDTO).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        Transaction transaction = transactionRepository.findById(id).orElse(null);

        if(transaction == null) {
            throw new NoTransactionException("no trasaction found");
        }
        return TransactionMapper.toDTO(transaction);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        TransactionDto transactionSavedInBDD = getLastByAccountId(transactionDto.getAccountId()); 
        transactionDto.setBalance(transactionSavedInBDD.getBalance() + transactionDto.getAmount());
        
        if(transactionDto.getBalance() < 0) {
            throw new NoBalanceException("no saldo dispoible");
        }
        transactionRepository.save(TransactionMapper.toTransaction(transactionDto));
        return transactionDto;
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        RestTemplate restTemplate = new RestTemplate();
        Client client = restTemplate.getForObject("http://localhost:8001/api/clients/"+clientId, Client.class);

        Set<Long> accountsIds = accountService.getAll().stream()
        .filter(a -> a.getClientId() == clientId)
        .map(ac -> ac.getId())
        .collect(Collectors.toSet());

        List<BankStatementDto> bankStatements = transactionRepository.findAccountsByClientAndDates(accountsIds, 
        dateTransactionStart, dateTransactionEnd);
        bankStatements.stream().forEach(ba -> ba.setClient(client.getName()));
        return bankStatements;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        Transaction transaction = transactionRepository.getLastByAccountId(accountId);
        if(transaction == null) {
            throw new NoTransactionException("no transaction found");
        }
        return TransactionMapper.toDTO(transaction);
    }
    
}
