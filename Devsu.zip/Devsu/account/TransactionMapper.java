package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

import com.devsu.hackerearth.backend.account.model.Transaction;

public class TransactionMapper {

    public static TransactionDto toDTO(Transaction transaction) {
        return new TransactionDto(
            transaction.getId(), 
            transaction.getDate(), 
            transaction.getType(), 
            transaction.getAmount(), 
            transaction.getBalance(), 
            transaction.getAccountId());
    }

    public static Transaction toTransaction(TransactionDto transactionDto) {
        Transaction transaction = new Transaction();
        transaction.setAccountId(transactionDto.getAccountId());
        transaction.setAmount(transactionDto.getAmount());
        transaction.setBalance(transactionDto.getBalance());
        transaction.setDate(transactionDto.getDate());
        transaction.setId(transactionDto.getId());
        transaction.setType(transactionDto.getType());
        return transaction;
    }
    
}
