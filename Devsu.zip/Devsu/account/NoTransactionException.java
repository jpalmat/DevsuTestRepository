package com.devsu.hackerearth.backend.account.exceptions;

public class NoTransactionException extends RuntimeException {
    
    public NoTransactionException(String message) {
        super(message);
    }
}
