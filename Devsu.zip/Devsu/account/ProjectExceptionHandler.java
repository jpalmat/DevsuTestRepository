package com.devsu.hackerearth.backend.account.exceptions;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ProjectExceptionHandler {

    @ExceptionHandler(NoAccountException.class) 
    public ResponseEntity<String> handleNoAccountException(NoAccountException ex) {
        return ResponseEntity.notFound().build();
    }
    
    @ExceptionHandler(NoTransactionException.class) 
    public ResponseEntity<String> handleNoTransactionException(NoTransactionException ex) {
        return ResponseEntity.notFound().build();
    }


    @ExceptionHandler(NoBalanceException.class) 
    public ResponseEntity<String> handleNoBalanceException(NoBalanceException ex) {
        return ResponseEntity.notFound().build();
    }
}
