package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@SpringBootTest
public class sampleTest {

	private AccountService accountService = mock(AccountService.class);
	private AccountController accountController = new AccountController(accountService);

	private TransactionService transactionService = mock(TransactionService.class);
	private TransactionController transactionController = new TransactionController(transactionService);

	@Test
	void createAccountTest() {
		// Arrange
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountController.create(newAccount);

		// Assert
		assertEquals(createdAccount, response.getBody());
	}

	@Test
	void createTransactionTest() {
		TransactionDto newTransaction = new TransactionDto(1L, new Date(2025, 03, 30), "Savings", 0, 0, 1L);
		TransactionDto createdTransaction = new TransactionDto(1L, new Date(2025, 03, 30), "Savings", 0, 0, 1L);
		
		when(transactionService.create(newTransaction)).thenReturn(createdTransaction);

		// Act
		ResponseEntity<TransactionDto> response = transactionController.create(newTransaction);

		// Assert
		assertEquals(createdTransaction, response.getBody());
	}
}

