package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exceptions.NoAccountException;
import com.devsu.hackerearth.backend.account.mapper.AccountToAccountDTO;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.model.Account;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository
        .findAll().stream().map(AccountToAccountDTO :: convertToAccountDTO).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        Account account = accountRepository.findById(id).orElse(null);

        if(account == null) {
            throw new NoAccountException("no account found");
        }
        return AccountToAccountDTO.convertToAccountDTO(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        Account account = accountRepository.save(AccountToAccountDTO.convertToAcccount(accountDto));
        return AccountToAccountDTO.convertToAccountDTO(account);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        Account account = accountRepository.findById(accountDto.getId()).orElse(null);
        if (account == null) {
            throw new NoAccountException("no account found");
        }
        Account accountSaved = accountRepository.save(AccountToAccountDTO.convertToAcccount(accountDto));
        return AccountToAccountDTO.convertToAccountDTO(accountSaved);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) {
            throw new NoAccountException("no account found");
        }

        Account accountSaved = accountRepository
        .save(AccountToAccountDTO.convertPartialToAccount(account, partialAccountDto));
        return AccountToAccountDTO.convertToAccountDTO(accountSaved);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        Account account = accountRepository.findById(id).orElse(null);
        if (account == null) {
            throw new NoAccountException("no account found");
        }
        accountRepository.deleteById(id);
    }
    
}
