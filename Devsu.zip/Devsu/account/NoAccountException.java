package com.devsu.hackerearth.backend.account.exceptions;

public class NoAccountException extends RuntimeException {
    
    public NoAccountException(String message) {
        super(message);
    }
}
