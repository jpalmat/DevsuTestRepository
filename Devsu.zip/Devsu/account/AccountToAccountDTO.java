package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.model.Account;

public class AccountToAccountDTO {
    
    public static AccountDto convertToAccountDTO(Account account) {
        return new AccountDto(
            account.getId(), 
            account.getNumber(), 
            account.getType(), 
            account.getInitialAmount(), 
            account.isActive(),
            account.getClientId());

    }

    public static Account convertToAcccount(AccountDto accountDto) {
        Account account = new Account();
        account.setClientId(accountDto.getClientId());
        account.setActive(accountDto.isActive());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());

        return account;
    }

    public static Account convertPartialToAccount(Account account, PartialAccountDto accountDto){
        account.setActive(accountDto.isActive());

        return account;
    }
}
