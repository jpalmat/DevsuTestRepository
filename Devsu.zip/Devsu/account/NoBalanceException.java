package com.devsu.hackerearth.backend.account.exceptions;

public class NoBalanceException extends RuntimeException {

    public NoBalanceException(String message) {
        super(message);
    }
}
