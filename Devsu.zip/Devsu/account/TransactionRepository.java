package com.devsu.hackerearth.backend.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    @Query("SELECT t.date, a.number, a.number, a.type, t.isActive, t.type, t.amount, t.balance"
    +" from Account a, Transaction t"
    + " where a.id = t.accountId"
    +" and a.id = :clientId"
    +" and t.date BETWEEN :dateStart AND :dateEnd")
    List<BankStatementDto> findAccountsByClientAndDates(@Param("clientId") Long clientId, @Param("dateStart") Date dateStart, @Param("dateEnd") Date dateEnd);

    @Query("SELECT t FROM Transaction t, Account a"
    +" where a.id = t.accountId"
    +" and a.id = :accountId"
    +" ORDER BY t.date DESC LIMIT 1")
    Transaction getLastByAccountId(@Param("accountId")Long accountId);
}
