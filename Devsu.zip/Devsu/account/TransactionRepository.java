package com.devsu.hackerearth.backend.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    @Query("SELECT t.date, a.number, a.type, a.isActive, t.type, t.amount, t.balance"
    +" from Account a, Transaction t"
    + " where a.id = t.accountId and t.accountId in :accountsIds"
    +" and t.date BETWEEN :dateStart AND :dateEnd")
    List<BankStatementDto> findAccountsByClientAndDates(@Param("accountsIds") Set<Long> accountsIds, 
    @Param("dateStart") Date dateStart, 
    @Param("dateEnd") Date dateEnd);

    Transaction getLastByAccountId(Long accountId);
}
