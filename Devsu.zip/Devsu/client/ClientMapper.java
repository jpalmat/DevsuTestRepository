package com.devsu.hackerearth.backend.client.mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;

public class ClientMapper {
    public static ClientDto toDto(Client client) {
        return new ClientDto(
            client.getId(), 
            client.getDni(), 
            client.getName(),
            client.getPassword(), 
            client.getGender(),
            client.getAge(),
            client.getAddress(),
            client.getPhone(), 
            client.isActive());
    }

    public static Client toClient(ClientDto clientDto) {
        Client client = new Client();
        
        return client;
    }

    public static Client fromPartialToClient(Client client, PartialClientDto partialClientDto) {
        client.setActive(partialClientDto.getActive());
        return client;
    }
}
