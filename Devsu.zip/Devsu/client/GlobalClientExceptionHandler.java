package com.devsu.hackerearth.backend.client.exceptions;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class GlobalClientExceptionHandler {
    @ExceptionHandler(NoClientException.class) 
    public ResponseEntity<String> handleNoClientException(NoClientException ex) {
        return ResponseEntity.badRequest().body("No client found");
    }    
}
