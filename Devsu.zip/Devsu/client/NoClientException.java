package com.devsu.hackerearth.backend.client.exceptions;

public class NoClientException extends RuntimeException{
    
    public NoClientException(String message) {
        super(message);
    }
}
