package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.exceptions.NoClientException;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll()
				.stream().map(ClientMapper::toDto).collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		Client client = clientRepository.findById(id).orElse(null);

		if (client == null) {
			throw new NoClientException("no client found");
		}
		return ClientMapper.toDto(client);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client client = clientRepository.save(ClientMapper.toClient(clientDto));
		return ClientMapper.toDto(client);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		
		Client client = clientRepository.findById(clientDto.getId()).orElse(null);
        if (client == null) {
            throw new NoClientException("no client found");
        }

        Client clientSaved = clientRepository.save(ClientMapper.toClient(clientDto));
		return ClientMapper.toDto(clientSaved);
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update Client
		Client client = clientRepository.findById(id).orElse(null);
        if (client == null) {
            throw new NoClientException("no client found");
        }
		
        Client clientSaved = clientRepository
        .save(ClientMapper.fromPartialToClient(client, partialClientDto));
		return ClientMapper.toDto(clientSaved);
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		Client client = clientRepository.findById(id).orElse(null);
        if (client == null) {
            throw new NoClientException("no client found");
        }
		clientRepository.deleteById(id);
	}
}
